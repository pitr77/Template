( function( $ ) {

	$( document ).ready( function( $ ) {

		$( '#musical-vibe-settings-metabox-container' ).tabs();

	});

} )( jQuery );
